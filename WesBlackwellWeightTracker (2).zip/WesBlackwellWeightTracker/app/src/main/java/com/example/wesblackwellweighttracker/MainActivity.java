package com.example.wesblackwellweighttracker;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.Manifest;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;


public class MainActivity extends AppCompatActivity implements TextWatcher {

    private static final int SEND_SMS_REQUEST_CODE = 0;
    private String mSessionToken = null;
    private TextView tv_error;
    private EditText et_password, et_username;

    /* TODO: figure out database setup and utilization
    private WeightTrackerDatabase weightApp_db;

    private boolean validateUserAndPass(String name, String password)
    {
        if (name.trim().length() <= 0 || password.trim().length() <= 0)
        {
            return false;
        }
        return weightApp_db.accountDao().getPassword(name);
    }

    private boolean hashUserAndPass(String name, String password)
    {
        String dbHash = weightApp_db.accountDao().getPassword(name);
        byte [] dbSalt = weightApp_db.accountDao().getSalt(name);

        return(dbHash != null) && (dbSalt != null) && dbHash.equals(HashAndSalter.getHash(password, dbSalt));
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null) {
            mSessionToken = savedInstanceState.getString("sessionToken");
        }

        if(mSessionToken != null){
            login();
        }

        et_username = findViewById(R.id.user);
        tv_error = findViewById(R.id.tv_loginFeedback);
        et_password = findViewById(R.id.pass);

        et_password.addTextChangedListener(this);
        et_username.addTextChangedListener(this);

        //weightApp_db = WeightTrackerDatabase.getInstance(getApplicationContext());
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("sessionToken", mSessionToken);
    }

    private void login()
    {
        Intent intent = new Intent(this, WeightTrackerActivity.class);
        intent.putExtra("username", mSessionToken);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        login();
    }


    public void onUserLoginClick(View view) {
        String name = et_username.getText().toString();
        String pass = et_username.getText().toString();
/*
        if (validateUserAndPass(name, pass))
        {
            mSessionToken = name;
            login();
        }*/
    }

    public void onCreateLoginClick(View view)
    {
        String newName = et_username.getText().toString();
        String newPass = et_username.getText().toString();

        /*
        if (validateUserAndPass(newName, newPass))
        {
            byte [] salt = HashAndSalter.getSalt();
            String hash = HashAndSalter.getHash(newPass, salt);

            weightApp_db.accountDao().addUser(new UserLogin(newName, hash, salt));

            mSessionToken = newName;

            FragmentManager manager = getSupportFragmentManager();
            SetGoalWeightLog weightLog = new SetGoalWeightLog;

            weightLog.show(manager, "setGoalWeight");
        }*/
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (tv_error.getVisibility() == View.INVISIBLE)
        {
            tv_error.setText("");
            tv_error.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}