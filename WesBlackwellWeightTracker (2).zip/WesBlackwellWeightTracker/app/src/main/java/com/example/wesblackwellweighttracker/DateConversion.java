package com.example.wesblackwellweighttracker;

import androidx.room.TypeConverter;

import java.util.Date;
public class DateConversion {

    @TypeConverter
    public static Date endDate(Long date)
    {
        return date == null ? null: new Date(date);
    }

    @TypeConverter
    public static long startDate(Date date)
    {
        return date == null ? null :date.getTime();
    }

}
