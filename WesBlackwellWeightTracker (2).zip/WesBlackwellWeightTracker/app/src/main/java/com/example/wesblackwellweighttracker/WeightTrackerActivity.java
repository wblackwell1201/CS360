package com.example.wesblackwellweighttracker;

import java.util.List;

public class WeightTrackerActivity {
    private List<WeightsList> weights;

}
