package com.example.wesblackwellweighttracker;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity(tableName = "weights", foreignKeys = @ForeignKey(entity = UserLogin.class, parentColumns = "username", childColumns = "username"))
@TypeConverters(DateConversion.class)
public class WeightsList {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    private int id_number;

    @ColumnInfo(name = "weight")
    private float weight = 0.f;

    @NonNull
    @ColumnInfo(name = "datetime")
    private Date date;

    @NonNull
    @ColumnInfo(name = "username")
    private String user;

    public void Weight(float weight, @NonNull String username)
    {
        date = new Date(System.currentTimeMillis());
        this.weight = weight;
        user = username;
    }

    public int getId()
    {
        return id_number;
    }

    public void setId(int mId)
    {
        this.id_number = mId;
    }

    public float getWeight()
    {
        return weight;
    }

    public void setWeight(float weight)
    {
        this.weight = weight;
    }

    @NonNull
    public Date getDateTime()
    {
        return date;
    }

    public void setDateTime(@NonNull Date dateTime)
    {
        this.date = dateTime;
    }

    @NonNull
    public String getUsername()
    {
        return user;
    }

    public void setUsername(@NonNull String name)
    {
        this.user = name;
    }
}
