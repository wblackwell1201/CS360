package com.example.wesblackwellweighttracker;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity(tableName = "usernames")
public class UserLogin
{
    @PrimaryKey
    @NonNull
    @ColumnInfo
    private String username = "";

    @NonNull
    @ColumnInfo
    private String password = "";

    @NonNull
    @ColumnInfo(name="salt", typeAffinity = ColumnInfo.BLOB)
    private byte [] mSalt = new byte [16];

    @ColumnInfo
    private float goalWeight = 0.f;

    public UserLogin(@NonNull String name, @NonNull String pass, @NonNull byte [] salt)
    {
        username = name;
        password = pass;
        mSalt = salt;
    }

    public void setUsername(@NonNull String name)
    {
        this.username = name;
    }

    public void setPassword(@NonNull String pass)
    {
        this.password = pass;
    }

    @NonNull
    public String getPassword()
    {
        return password;
    }

    public String getUsername()
    {
        return username;
    }

    @NonNull
    public byte [] getSalt()
    {
        return mSalt;
    }

    public void setSalt(@NonNull byte [] salt)
    {
        this.mSalt = salt;
    }

    public float getGoalWeight()
    {
        return goalWeight;
    }

    public void setGoalWeight(float goalWeight)
    {
        this.goalWeight = goalWeight;
    }
}
